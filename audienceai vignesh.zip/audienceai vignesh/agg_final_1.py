import os
import re
import pandas as pd
from langchain_community.utilities import SQLDatabase
from langchain_community.agent_toolkits import create_sql_agent
from langchain_openai import ChatOpenAI
from langchain.chains import create_sql_query_chain
import logging

# Enable SQLAlchemy logging to debug queries
logging.basicConfig()
logging.getLogger('sqlalchemy.engine').setLevel(logging.INFO)

class SQLDatabaseAgent:
    def __init__(self, db_uri, openai_api_key, model="gpt-4o"):
        """Initialize the database connection and language model with explicit API key."""
        self.db_uri = db_uri
        self.db = None
        self.llm = ChatOpenAI(model=model, temperature=0, openai_api_key=openai_api_key)

    def _connect_db(self):
        """Establish and return a persistent database connection."""
        if self.db is None:
            try:
                self.db = SQLDatabase.from_uri(self.db_uri)
                print("Database connection established successfully.")
            except Exception as e:
                print(f"Error establishing database connection: {e}")
                return None
        return self.db

    def _ensure_db_connection(self):
        """Ensure that the database connection is active."""
        if not self.db:
            print("Database connection is not established, attempting to reconnect...")
            self._connect_db()

    def list_tables_and_columns(self):
        """List all tables and columns from the database."""
        db = self._connect_db()  # Ensure the connection is established
        if db:
            try:
                agent_executor = create_sql_agent(self.llm, db=db, agent_type="openai-tools", verbose=True)
                response = agent_executor.invoke("can you list all tables and its columns only listed")
                output = response["output"]
                return self._parse_table_column_output(output)
            except Exception as e:
                print(f"Error fetching tables and columns: {e}")
        return None

    def _parse_table_column_output(self, output):
        """Parse the response from the language model to extract table-column pairs."""
        data = []
        try:
            tables = re.findall(r'- Table: (\w+)\n\s+- Columns: ([\w,\s]+)', output)
            for table, columns in tables:
                columns = [col.strip() for col in columns.split(',')]
                for column in columns:
                    data.append({"table": table, "column": column})
            df = pd.DataFrame(data)
            return df
        except Exception as e:
            print(f"Error parsing table and column output: {e}")
        return None

    def combine_tables(self, table_column_pairs, combined_metrics):
        """Generate SQL query to combine all tables."""
        self._ensure_db_connection()  # Check connection before running the query
        if self.db:
            try:
                result = table_column_pairs.to_dict(orient='records')
                prompt = f"""
                Combine all {result} into one table using SQL.
                Map common columns, e.g., 'date' and 'activity_date', and use {combined_metrics} for combining.
                Generate SQL with unions and joins to create a singular table.
                """
                chain = create_sql_query_chain(self.llm, self.db)
                response = chain.invoke({"question": prompt})
                extracted_sql = re.search(r'```sql\n(.*?)\n```', response, re.DOTALL).group(1)
                return extracted_sql
            except Exception as e:
                print(f"Error generating combined table SQL: {e}")
        return None

    def create_combined_table(self, extracted_sql, table_name="combined"):
        """Execute the SQL query to create a combined table."""
        self._ensure_db_connection()  # Check connection before running the query
        if self.db:
            try:
                create_table_query = f"CREATE TABLE IF NOT EXISTS {table_name} AS {extracted_sql}"
                print(f"Executing query: {create_table_query}")  # Print the query for debugging
                self.db.run(create_table_query)
                print(f"Table '{table_name}' created successfully!")
            except Exception as e:
                print(f"Error creating combined table: {e}")
                if "sqlalchemy.exc.OperationalError" in str(e):
                    print("OperationalError: Check your SQL query or database connection. More details at: https://sqlalche.me/e/14/e3q8")

    def generate_aggregation_query(self, group_by_columns):
        """Generate the SQL query for aggregation."""
        self._ensure_db_connection()  # Check connection before running the query
        if self.db:
            try:
                prompt = f"""
                Generate SQL query for aggregation on the table 'combined', grouped by {group_by_columns}.
                Only use columns from the combined table.
                """
                chain = create_sql_query_chain(self.llm, self.db)
                response = chain.invoke({"question": prompt})
                extracted_sql = re.search(r'```sql\n(.*?)\n```', response, re.DOTALL).group(1)
                return extracted_sql
            except Exception as e:
                print(f"Error generating aggregation SQL query: {e}")
        return None

    def create_aggregated_table(self, extracted_sql, table_name="aggregated_table"):
        """Execute the SQL query to create an aggregated table."""
        self._ensure_db_connection()  # Check connection before running the query
        if self.db:
            try:
                create_table_query = f"CREATE TABLE IF NOT EXISTS {table_name} AS {extracted_sql}"
                print(f"Executing query: {create_table_query}")
                self.db.run(create_table_query)
                print(f"Table '{table_name}' created successfully!")
            except Exception as e:
                print(f"Error creating aggregated table: {e}")

    def get_user_input(self):
        """Helper method to get user input."""
        user_input = {}
        user_input['combined_metrics'] = input("Specify how to combine metrics (e.g., fb_impressions + google_impressions AS total_impressions): ")
        return user_input

    def get_group_by_columns(self):
        """Helper method to get user input for grouping columns."""
        return input("Which columns would you like to group by? (e.g., date, campaign): ")

# Usage Example:

if __name__ == "__main__":
    # Replace with your actual OpenAI API key
    openai_api_key = os.getenv("OPENAI_API_KEY", "your_openai_api_key_here")
    db_agent = SQLDatabaseAgent(db_uri="sqlite:///temp_db.db", openai_api_key="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")

    # Step 1: List tables and columns
    df = db_agent.list_tables_and_columns()
    if df is not None:
        print(df)

        # Step 2: Get user input for combining metrics
        user_input = db_agent.get_user_input()

        # Step 3: Combine tables using the user input
        extracted_sql = db_agent.combine_tables(df, user_input['combined_metrics'])
        if extracted_sql:
            print(extracted_sql)

            # Step 4: Create combined table in the database
            db_agent.create_combined_table(extracted_sql)

            # Step 5: Get user input for aggregation (grouping)
            group_by_columns = db_agent.get_group_by_columns()

            # Step 6: Generate and execute aggregation query
            aggregation_sql = db_agent.generate_aggregation_query(group_by_columns)
            if aggregation_sql:
                print(aggregation_sql)
                db_agent.create_aggregated_table(aggregation_sql)
    else:
        print("Failed to list tables and columns. Check database connection and retry.")
