import boto3
from botocore.exceptions import ClientError
import logging

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

class Match:
    def __init__(self, conversation=[]):
        self.conversation = conversation
        self.bedrock_client = boto3.client(service_name='bedrock-runtime')
        self.model_id = 'anthropic.claude-3-5-sonnet-20240620-v1:0'
        self.system_prompts = []
        
    def ping(self, prompt, tokens=1000):

        message = {"role": "user", "content": [{"text":prompt}]}
        self.conversation.append(message)

        logger.info("Generating message with model %s", self.model_id)
        # Inference parameters to use.
        temperature = 0.5
        top_k = 200

        # Base inference parameters to use.
        inference_config = {"temperature": temperature, "maxTokens": tokens}
        # Additional inference parameters to use.
        additional_model_fields = {"top_k": top_k}

        # Send the message.
        response = self.bedrock_client.converse(
            modelId=self.model_id,
            messages=self.conversation,
            system=self.system_prompts,
            inferenceConfig=inference_config,
            additionalModelRequestFields=additional_model_fields
        )

        # Log token usage.
        token_usage = response['usage']
        logger.info("Input tokens: %s", token_usage['inputTokens'])
        logger.info("Output tokens: %s", token_usage['outputTokens'])
        logger.info("Total tokens: %s", token_usage['totalTokens'])
        logger.info("Stop reason: %s", response['stopReason'])

        resp = response['output']['message']

        self.conversation.append(resp)

        r = resp['content'][0]['text']

        print(r)
        return r
        
    def get_conversation(self):
        return self.conversation