import pandas as pd
import numpy as np
import boto3
from sklearn.preprocessing import OneHotEncoder, normalize, StandardScaler
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.impute import SimpleImputer


class DataAnalyzer:
    def __init__(self):
        self.file_path = 's3://audmod/input/'
        self.fname = 'dat.csv'
        self.df = None
        self.df_encoded = None
        self.df_reduced = None
        self.clusters = None
        self.summary = None

    def load_data(self):
        self.df = pd.read_csv(self.file_path+self.fname)
        self.df = self.df.drop(columns=['Customer ID'])
        return self

    def one_hot_encode(self):
        categorical_columns = self.df.select_dtypes(include=['object']).columns
        encoder = OneHotEncoder(handle_unknown='ignore')
        encoded = encoder.fit_transform(self.df[categorical_columns]).toarray()
        encoded_df = pd.DataFrame(encoded, columns=encoder.get_feature_names_out(categorical_columns))
        self.df_encoded = pd.concat([self.df.drop(categorical_columns, axis=1), encoded_df], axis=1)
        return self

    def reduce_dimensions(self):
        numeric_columns = self.df_encoded.select_dtypes(include=['float64', 'int64']).columns
        imputer = SimpleImputer(strategy='mean')
        #df_imputed = pd.DataFrame(imputer.fit_transform(self.df_encoded[numeric_columns]), columns=numeric_columns)
        #df_normed = normalize(df_imputed[numeric_columns], axis=0)

        df_imputed = self.df_encoded[numeric_columns][['Age','Purchase Amount (USD)']]
        scaler = StandardScaler()
        df_scaled = scaler.fit_transform(df_imputed)
        
        #pca = PCA(n_components=2)
        #reduced = pca.fit_transform(df_scaled)
        #tsne = TSNE()
        #reduced = pca.fit_transform(df_scaled)
        #self.df_reduced = pd.DataFrame(reduced, columns=[f'PC{i+1}' for i in range(reduced.shape[1])])
        self.df_reduced = df_scaled #df_scaled[['Age','Purchase Amount (USD)']].to_numpy()
        return self

    def perform_clustering(self):
        min_clusters = 3
        max_clusters = 5
        silhouette_scores = []

        for n_clusters in range(min_clusters, max_clusters + 1):
            kmeans = KMeans(n_clusters=n_clusters, random_state=42)
            cluster_labels = kmeans.fit_predict(self.df_reduced)
            silhouette_scores.append(silhouette_score(self.df_reduced, cluster_labels))

        optimal_clusters = silhouette_scores.index(max(silhouette_scores)) + min_clusters
        kmeans = KMeans(n_clusters=optimal_clusters, random_state=42)
        self.clusters = kmeans.fit_predict(self.df_reduced)
        return self

    def create_summary(self):
        self.df['Cluster'] = self.clusters
        self.summary = self.df.groupby('Cluster').describe()
        self.summary.to_csv(self.file_path+'cluster_summary.csv')
        self.df.to_csv(self.file_path+'cluster_membership.csv')
        return self

    def run_analysis(self):
        (self.load_data()
             .one_hot_encode()
             .reduce_dimensions()
             .perform_clustering()
             .create_summary())
        print("Analysis complete. Summary statistics saved to 'cluster_summary.csv'")