import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import re
from io import StringIO
from openai import OpenAI
import os

# Set up the OpenAI API key using environment variable
api_key = os.getenv("OPENAI_API_KEY")

def chat_with_clusters(prompt):
    try:
        client = OpenAI(api_key="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")
        completion = client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "system", "content": "You are a helpful marketing data analyst that helps me with customer segmentation!"},
                      {"role": "user", "content": f'''{prompt}'''}]
        )
        return completion.choices[0].message.content
    except Exception as e:
        st.error(f"Error contacting OpenAI: {str(e)}")
        return ""

# Function to parse clusters from the OpenAI result
def extract_clusters(result):
    clusters = re.split(r'(Cluster \d+:)', result)
    cluster_data = []
    for i in range(1, len(clusters), 2):
        title = clusters[i].strip()
        description = clusters[i + 1].strip()
        cluster_data.append((title, description))
    return cluster_data

# Streamlit configuration
st.set_page_config(layout='wide')

# Custom CSS for gradient background
st.markdown(
    """
    <style>
    .stApp {
        background: linear-gradient(135deg, #FFFFFF, #E5FF74) !important;  /* Warm yellow to light lemon yellow */
        background-attachment: fixed !important;
        height: 100vh; /* Ensures the gradient covers the full height */
    }
    </style>
    """,
    unsafe_allow_html=True
)

st.title("Softcrylic AI Audience Segmentation")
logo = r"./AudienceMatchAI logo color.svg"  # Ensure the image is in the app's directory
st.image(logo, width=300)

# Load data from local files
data1 = pd.read_csv(r"./numerical.csv")  # Replace with actual local file path
data2 = pd.read_csv(r"./Categorical.csv")  # Replace with actual local file path
data3 = pd.read_csv(r"./cluster_data.csv")  # Replace with actual local file path

# Replace values in 'Cluster' column with descriptive names
cluster_mapping = {0: 'cluster_0', 1: 'cluster_1', 2: 'cluster_2', 3: 'cluster_3'}
data3['Cluster'] = data3['Cluster'].map(cluster_mapping)
data4 = data3

# Initialize session state for clusters and result
if 'clusters' not in st.session_state:
    st.session_state.clusters = []

if 'result' not in st.session_state:
    st.session_state.result = ""

if 'conversation' not in st.session_state:
    st.session_state.conversation = []  # Initialize conversation history

try:
    col1, col2, col3 = st.columns([1, 1, 1])

    with col3:
        st.info("Audience Loaded Successfully")
        st.dataframe(data1, use_container_width=True)
        st.dataframe(data2, use_container_width=True)

    # User input for chart and analysis
    with col3:
        st.info("Audience Segmentation Visualization")

        # Chart options
        column_options = data3.columns.tolist()
        x_axis = st.selectbox('Select column for X-axis', column_options)
        y_axis = st.selectbox('Select column for Y-axis', column_options)
        chart_type = st.radio('Select chart type', ('Scatter Plot', 'Bar Chart'))

        if x_axis and y_axis:
            st.write(f"### {chart_type} of {x_axis} vs {y_axis}")

            # Check the data types
            data4[y_axis] = pd.to_numeric(data4[y_axis], errors='coerce')  # Ensure Y-axis is numeric

            x_is_categorical = data4[x_axis].dtype == 'object' or data4[x_axis].dtype.name == 'category'
            y_is_numeric = pd.api.types.is_numeric_dtype(data4[y_axis])

            plt.figure(figsize=(6, 3))

            if chart_type == 'Scatter Plot':
                if not (x_is_categorical and not y_is_numeric):
                    sns.scatterplot(x=data4[x_axis], y=data4[y_axis])
                else:
                    st.error("Scatter plots require at least one numeric variable.")

            elif chart_type == 'Bar Chart':
                if x_is_categorical and y_is_numeric:
                    if data4[y_axis].isnull().all():
                        st.error(f"The selected Y-axis ({y_axis}) has no valid numeric values.")
                    else:
                        bar_data = data4.groupby(x_axis)[y_axis].mean().reset_index()  # Calculate mean of the Y-axis by the X-axis categories
                        sns.barplot(x=bar_data[x_axis], y=bar_data[y_axis])
                else:
                    st.error("Bar charts require the X-axis to be categorical and the Y-axis to be numeric.")

            plt.title(f"{chart_type} of {x_axis} vs {y_axis}")
            st.pyplot(plt)

    st.dataframe(data4, use_container_width=True)

    with col1:
        # Summarize Audience Segments
        if st.button("Summarize Audience Segments"):
            prompt = f'''Here are the clusters we are going to analyze. There are two datasets: one for numerical variables is {data1} and one for 
categoricals is {data2}. Followed by a brief description of each cluster and pithy, descriptive persona titles for each you would associate with each cluster. 
Justify the cluster persona names with bullet point statistics.
Use format
''old_cluster_name: The new name
debrief description of this cluster
    1.key point_1
    2.key point_2
    3.key point_3
    4.key point_4
    n.key point_n

old_cluster_name: The new name
debrief description of this cluster
    1.key point_1
    2.key point_2
    3.key point_3
    4.key point_4
    n.key point_n

old_cluster_name: The new name 
debrief description of this cluster
    1.key point_1
    2.key point_2
    3.key point_3
    4.key point_4
    n.key point_n''
the output should be only like the given format
'''

            result = chat_with_clusters(prompt)

            # Store result in session state
            st.session_state.result = result

            # Parse the result into clusters and store in session state
            st.session_state.clusters = extract_clusters(result)

        # Display clusters in a collapsible dropdown in Column 1
        count = 0  # Start count at 1 for segment_1
        for title, description in st.session_state.clusters:
            with st.expander(f"Segment_{count}", expanded=False):
                st.text_area(label=f"Segment_{count}", value=description, height=200, key=f"cluster_text_area_{count}",label_visibility="hidden")
                count += 1  # Increment count for each segment

        # Prepare the result for download
        if st.session_state.result:
            buffer = StringIO()
            buffer.write(st.session_state.result)
            buffer.seek(0)

            st.download_button(
                label="Download Summary",
                data=buffer.getvalue(),
                file_name="audience_summary.txt",
                mime="text/plain"
            )

    with col2:
        # Display the full conversation history above the input text box
        conversation_display = "\n\n".join(f"{role}: {msg}" for role, msg in st.session_state.conversation)
        st.text_area("Chat:", value=conversation_display, height=400)

        # Input text box for the user's query below the conversation history
        prompt = st.text_area("Enter your query for audience segments (e.g., 'What are the key demographics for Cluster A?')")

        if prompt and st.button("Ask Assistant"):
            # Append user query to the conversation history
            st.session_state.conversation.append(("User", prompt))

            # Construct the full conversation history for the prompt
            if st.session_state.result:  # Only include result if it exists
                data1_string = data1.to_string(index=False)  # Convert data1 to string without the index
                data2_string = data2.to_string(index=False)  # Convert data2 to string without the index
                initial_prompt = (
                    f"This is the cluster information you should only answer questions based on this: {st.session_state.result}\n"
                    f"Here are the numerical data:\n{data1_string}\n"
                    f"Here are the categorical data:\n{data2_string}"
                )
            else:
                initial_prompt = "This is the cluster information you should only answer questions based on this: No cluster information available."

            full_conversation = "\n\n".join(f"{role}: {msg}" for role, msg in st.session_state.conversation)
            chat_input = f'''{initial_prompt}\n{full_conversation}\nUser: {prompt}'''
            response = chat_with_clusters(chat_input)

            # Append the system response to the conversation history
            st.session_state.conversation.append(("Audience AI", response))

            # Clear the input box after submission
            st.experimental_rerun()  # Rerun the app to show the updated conversation history

except Exception as e:
    st.error(f"An error occurred while processing the data: {str(e)}")
