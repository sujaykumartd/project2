import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, MinMaxScaler, OrdinalEncoder, OneHotEncoder
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from umap import UMAP
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
from sklearn.metrics import silhouette_score, davies_bouldin_score, make_scorer
from sklearn.impute import KNNImputer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import ParameterGrid, GridSearchCV
from sklearn.neighbors import NearestNeighbors
import hdbscan
import multiprocessing
from functools import partial
from concurrent.futures import ProcessPoolExecutor, as_completed
from statsmodels.stats.outliers_influence import variance_inflation_factor
from kneed import KneeLocator
import time
import logging
import os
from datetime import datetime
import joblib
from dimension_red import DimensionReductionOptimiser


class ModelSelector:
    """
    A class for selecting the best clustering model based on various preprocessing and dimension reduction techniques.

    Parameters
    ----------
    data : pandas.DataFrame
        The input data to be clustered.

    Attributes
    ----------
    data : pandas.DataFrame
        The input data.
    transformed_data : pandas.DataFrame
        The preprocessed data.
    scaled_data : dict
        Dictionary containing scaled versions of the data.
    reduced_data : dict
        Dictionary containing dimension-reduced versions of the data.
    results : list
        List to store results of different clustering models.
    preprocessor : object
        The preprocessing pipeline.
    random_seed : int
        Random seed for reproducibility.
    """

    def __init__(self, data):
        self.data = data
        self.transformed_data = None
        self.scaled_data = {}
        self.reduced_data = {}
        self.results = []
        self.preprocessor = None
        self.random_seed = 42
        logging.info("ModelSelector initialized")

    def prepare_data_for_preprocessing(self):
        """
        Prepare the data for preprocessing by removing features with high missing values
        and identifying numeric and categorical columns.

        Returns
        -------
        None
        """

        # Checking for the primary key 
        unique_col = [col for col in self.data.columns if self.data[col].nunique() == len(self.data)]
        self.data.set_index(unique_col, inplace=True)


        
        logging.info("Starting prepare_data_for_preprocessing")
        # Remove features with 80% or more missing values
        missing_threshold = len(self.data) * 0.8
        filtered_data = self.data.dropna(axis=1, thresh=missing_threshold)
        
        # Identify numeric and categorical columns  
        one_hot_cat_col = []
        ordinal_cat_col = []
        numerical_features = self.data.select_dtypes(include=['int64', 'float64']).columns
        categorical_features = self.data.select_dtypes(include=['object']).columns
        for feature in categorical_features:
            unique_values = self.data[feature].nunique()
            if unique_values < 4:
                one_hot_cat_col.append(feature)
            else:
                ordinal_cat_col.append(feature)
        self.one_hot_cat_col = one_hot_cat_col
        self.ordinal_cat_col = ordinal_cat_col
        self.numerical_col = numerical_features
        logging.info("Finished prepare_data_for_preprocessing")

    def data_preprocess_pipeline(self):
        """
        Create and apply the data preprocessing pipeline.

        Returns
        -------
        None
        """
        logging.info("Starting data_preprocess_pipeline")
        # Build preprocessing pipeline for numerical features
        logging.info("KNN imputer for missing values")
        numerical_pipeline = Pipeline(steps=[
            ('imputer', KNNImputer(n_neighbors=5)),
        #     ('scaler', MinMaxScaler())
        ])
        # Build preprocessing pipeline for categorical features
        logging.info("One hot encoding for the Categorical features with less than 4 unique values")
        
        onehot_categorical_pipeline = Pipeline(steps=[
            ('onehot_encoding', OneHotEncoder(sparse_output=False, handle_unknown='ignore'))])
        
        logging.info("Ordinal encoding for the Categorical features with greater than 4 unique values")

        ordinal_categorical_pipeline = Pipeline(steps=[
            ('ordinal_encoding', OrdinalEncoder())

        ])
        column_transform = ColumnTransformer([
            ('numerical_columns', numerical_pipeline, self.numerical_col),
            ('onehot_categorical_columns', onehot_categorical_pipeline, self.one_hot_cat_col),
            ('ordinal_categorical_columns', ordinal_categorical_pipeline, self.ordinal_cat_col)   
        ])
        self.transformed_data = pd.DataFrame(column_transform.fit_transform(self.data)) 
        one_hot_cols = list(onehot_categorical_pipeline.fit(self.data[self.one_hot_cat_col]).get_feature_names_out())   
        trans_cols = list(self.numerical_col)+one_hot_cols+list(self.ordinal_cat_col)  
        self.transformed_data.columns = trans_cols 
        self.transformed_data.to_csv('transformed_data.csv', index=False)
        logging.info("Finished data_preprocess_pipeline")

    def remove_multicollinearity(self, correlation_threshold=0.85, use_vif=False, vif_threshold=5):
        """
        Remove multicollinearity from the transformed data.

        Parameters
        ----------
        correlation_threshold : float, optional
            The threshold for correlation above which features are considered collinear (default is 0.85).
        use_vif : bool, optional
            Whether to use Variance Inflation Factor (VIF) for multicollinearity detection (default is False).
        vif_threshold : float, optional
            The threshold for VIF above which features are considered to have high multicollinearity (default is 5).

        Returns
        -------
        None
        """
        logging.info("Starting remove_multicollinearity")
        # Remove highly correlated features
        corr_matrix = self.transformed_data.corr().abs()
        upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
        to_drop = [column for column in upper.columns if any(upper[column] > correlation_threshold)]
        self.transformed_data = self.transformed_data.drop(to_drop, axis=1)

        if use_vif:
            # Calculate VIF and remove features with high VIF
            X = self.transformed_data.values
            vif = pd.DataFrame()
            vif["features"] = self.transformed_data.columns
            vif["VIF"] = [variance_inflation_factor(X, i) for i in range(X.shape[1])]
            
            while vif["VIF"].max() > vif_threshold:
                feature_to_drop = vif.loc[vif["VIF"].idxmax(), "features"]
                self.transformed_data = self.transformed_data.drop(feature_to_drop, axis=1)
                
                X = self.transformed_data.values
                vif = pd.DataFrame()
                vif["features"] = self.transformed_data.columns
                vif["VIF"] = [variance_inflation_factor(X, i) for i in range(X.shape[1])]
        logging.info("Finished remove_multicollinearity")

    def scale_data(self):
        """
        Scale the transformed data using normalization and standardization.

        Returns
        -------
        None
        """
        logging.info("Starting scale_data")
        numerical_columns = self.numerical_col  # Assuming this list was saved in prepare_data
        categorical_columns = [col for col in self.transformed_data.columns if col not in numerical_columns]

        # Scale only numerical columns
        scaled_numerical_norm = pd.DataFrame(MinMaxScaler().fit_transform(self.transformed_data[numerical_columns]), 
                                             columns=numerical_columns, 
                                             index=self.transformed_data.index)
        scaled_numerical_std = pd.DataFrame(StandardScaler().fit_transform(self.transformed_data[numerical_columns]), 
                                            columns=numerical_columns, 
                                            index=self.transformed_data.index)

        # Concatenate scaled numerical data with categorical data
        self.scaled_data['normalization'] = pd.concat([scaled_numerical_norm, self.transformed_data[categorical_columns]], axis=1)
        self.scaled_data['standardization'] = pd.concat([scaled_numerical_std, self.transformed_data[categorical_columns]], axis=1)

                # Save feature names
        self.feature_names = list(self.transformed_data.columns)

        logging.info(f"Finished scale_data. Features: {', '.join(self.feature_names)}")

    # def find_best_n_components(self, method, scaling_method, threshold=0.95):
    #     """
    #     Find the best number of components for dimension reduction methods.

    #     Parameters
    #     ----------
    #     method : str
    #         The dimension reduction method ('PCA', 'TSNE', or 'UMAP').
    #     scaling_method : str
    #         The scaling method used ('normalization' or 'standardization').
    #     threshold : float, optional
    #         The variance threshold for PCA (default is 0.95).

    #     Returns
    #     -------
    #     int
    #         The best number of components.
    #     """
    #     logging.info(f"Starting find_best_n_components for {method}")
    #     print(method,scaling_method)
    #     if method == 'PCA':
    #         logging.info("Applying PCA to find best n_components")
    #         pca = PCA(random_state=self.random_seed)
    #         pca.fit(self.scaled_data[scaling_method])  # Use standardized data for PCA
    #         # return pca
    #         print('pca fit done')
    #         cumulative_variance = np.cumsum(pca.explained_variance_ratio_)
    #         n_components = np.argmax(cumulative_variance >= threshold) + 1
    #         result = max(2, min(n_components, 10))  # Ensure it's between 4 and 10
    #         logging.info(f"Best n_components for PCA: {result}")
    #     elif method in ['UMAP', 'TSNE']:
    #         n_components_range = range(4, 11) if method == 'UMAP' else [2, 3]
    #         logging.info(f"Evaluating {method} for n_components range: {list(n_components_range)}")
    #         with ProcessPoolExecutor() as executor:
    #             evaluate_func = partial(self.evaluate_n_components, method=method, scaling_method=scaling_method)
    #             results = list(executor.map(evaluate_func, n_components_range))
    #         result, best_score = max(zip(n_components_range, results), key=lambda x: x[1])
    #         logging.info(f"Best n_components for {method}: {result} with score: {best_score}")
    #     else:
    #         raise ValueError("Unsupported dimension reduction method")
    #     logging.info(f"Finished find_best_n_components for {method}. Best n_components: {result}")
    #     return result

    # def evaluate_n_components(self, n, method, scaling_method):
    #     """
    #     Evaluate the performance of a given number of components for a dimension reduction method.

    #     Parameters
    #     ----------
    #     n : int
    #         The number of components to evaluate.
    #     method : str
    #         The dimension reduction method.

    #     Returns
    #     -------
    #     float
    #         The silhouette score for the given number of components.
    #     """
    #     logging.info(f"Evaluating {n} components for {method}")
    #     print(f"Evaluating {n} components for {method}")
    #     reduced_data = self.apply_dimension_reduction(method, n, scaling_method)
    #     kmeans = KMeans(n_clusters=3, random_state=self.random_seed)
    #     labels = kmeans.fit_predict(reduced_data)
    #     score = silhouette_score(self.scaled_data[scaling_method], labels)
    #     logging.info(f"Silhouette score for {n} components: {score}")
    #     return score


    # def parallel_find_best_n_components(self, method, scaling_method):
    #     """
    #     Evaluate the performance of a given number of components for a dimension reduction method.

    #     Parameters
    #     ----------
    #     method : str
    #         The dimension reduction method.




    def apply_dimension_reduction(self, args):
        """
        Apply dimension reduction to the scaled data.

        Parameters
        ----------
        method : str
            The dimension reduction method ('PCA', 'TSNE', or 'UMAP').
        n_components : int
            The number of components to use.
        scaling_method : str
            The scaling method used ('normalization' or 'standardization').

        Returns
        -------
        numpy.ndarray
            The reduced data.
        """
        scaling_method,method= args
        # print(scaling_method,method)
        n_components = self.n_components['normalization'][method]
        logging.info(f"Applying {method} with {n_components} components")
        if method == 'PCA':
            reducer = PCA(n_components=n_components)
        elif method == 'TSNE':
            reducer = TSNE(n_components=n_components)
        elif method == 'UMAP':
            reducer = UMAP(n_components=n_components)
        result = reducer.fit_transform(self.scaled_data[scaling_method])
        # print(result)
        logging.info(f"Finished applying {method}")
        # result_dict = {scaling_method:{method:result}}
        return result

    def evaluate_model(self, data, labels):
        """
        Evaluate the clustering model using silhouette score and Davies-Bouldin score.

        Parameters
        ----------
        data : numpy.ndarray
            The data used for clustering.
        labels : numpy.ndarray
            The cluster labels.

        Returns
        -------
        tuple
            A tuple containing the silhouette score and Davies-Bouldin score.
        """
        logging.info("Evaluating model")
        sil_score = silhouette_score(data, labels)
        db_score = davies_bouldin_score(data, labels)
        logging.info(f"Silhouette score: {sil_score}, Davies-Bouldin score: {db_score}")
        return sil_score, db_score

    def process_model(self, args):
        """
        Process a single clustering model with given parameters.

        Parameters
        ----------
        args : tuple
            A tuple containing scaling method, dimension reduction method, model name, and model object.

        Returns
        -------
        dict or None
            A dictionary containing the results of the model evaluation, or None if the model is not created.
        """
        model_name, model,scaling_method, dim_method = args
        logging.info(f"Processing model: {model_name} with {scaling_method} scaling and {dim_method} dimension reduction")
        reduced_data = self.reduced_data[(scaling_method, dim_method)]
        scaled_data = self.scaled_data[scaling_method]

        n_clusters = None  # Default for DBSCAN and HDBSCAN
        if model_name == 'KMeans' or model_name == 'Agglomerative':
            n_clusters = self.select_best_n_clusters(reduced_data, model_name)
            if n_clusters is not None:
                    model.set_params(n_clusters=n_clusters)
                    labels = model.fit_predict(reduced_data)
            else:
                logging.info(f"Model not created because n_clusters is None for {model_name}")
                return None 

        else:
            labels = model.fit_predict(reduced_data)

        if len(np.unique(labels)) < 4:
            logging.info(f"Model not created because less than 4 clusters were found for {model_name}")
            return None
        sil_score, db_score = self.evaluate_model(scaled_data, labels)
        result = {
            'model': model_name,
            'scaling_method': scaling_method,
            'dim_reduction_method': dim_method,
            'n_components': self.n_components['normalization'][dim_method],
            'n_clusters': n_clusters,
            'silhouette_score': sil_score,
            'davies_bouldin_score': db_score
        }
        logging.info(f"Finished processing model: {model_name}")
        return result

    def select_best_n_clusters(self, data, model_type):
        """
        Select the best number of clusters for KMeans and Agglomerative clustering.

        Parameters
        ----------
        data : numpy.ndarray
            The data used for clustering.
        model_type : str
            The type of clustering model ('KMeans' or 'Agglomerative').

        Returns
        -------
        int
            The best number of clusters.
        """
        logging.info(f"Selecting best n_clusters for {model_type}")
        cluster_range = range(4, 11)

        if model_type == 'KMeans':
            # KMeans - Elbow Method
            inertias = []
            for n in cluster_range:
                kmeans = KMeans(n_clusters=n, random_state=self.random_seed)
                kmeans.fit(data)
                inertias.append(kmeans.inertia_)

            kl = KneeLocator(cluster_range, inertias, curve='convex', direction='decreasing')
            result = kl.elbow
        elif model_type == 'Agglomerative':
            # Agglomerative - Using evaluate_model function
            scores = []
            for n in cluster_range:
                agglomerative = AgglomerativeClustering(n_clusters=n)
                labels = agglomerative.fit_predict(data)
                sil_score, _ = self.evaluate_model(data, labels)
                scores.append(sil_score)

            result = cluster_range[np.argmax(scores)]
        logging.info(f"Best n_clusters for {model_type}: {result}")
        return result

    def select_best_model(self, correlation_threshold=0.85, use_vif=False, vif_threshold=5):
        """
        Select the best clustering model based on various preprocessing and dimension reduction techniques.

        Parameters
        ----------
        correlation_threshold : float, optional
            The threshold for correlation in multicollinearity removal (default is 0.85).
        use_vif : bool, optional
            Whether to use Variance Inflation Factor for multicollinearity removal (default is False).
        vif_threshold : float, optional
            The threshold for VIF in multicollinearity removal (default is 5).

        Returns
        -------
        tuple
            A tuple containing the best model, scaling method, dimension reduction method, number of components,
            number of clusters, and a DataFrame of all results.
        """
        logging.info("Starting select_best_model")
        self.prepare_data_for_preprocessing()
        self.data_preprocess_pipeline()
        self.remove_multicollinearity(correlation_threshold, use_vif, vif_threshold)
        self.scale_data()
        scaling_methods = ['normalization', 'standardization']
        dim_reduction_methods = ['PCA', 'TSNE', 'UMAP']

        models = {
            'KMeans': KMeans(random_state=self.random_seed),  # n_clusters will be set in process_model
            'DBSCAN': DBSCAN(eps=0.5, min_samples=5),
            'Agglomerative': AgglomerativeClustering(),  # n_clusters will be set in process_model
            'HDBSCAN': hdbscan.HDBSCAN(min_cluster_size=5)
        }

        # Find best n_components for each dimension reduction method, the n_components will be used in process_model and remined same for both scaling methods
        #  so Extracting n components for only one scaling method and using it for both scaling methods
        logging.info("Initializing DimensionReductionOptimiser")
        logging.info("finding best n_components of dimension reduction methods in parallel")
        start_time = time.time()
        dim_optimiser = DimensionReductionOptimiser(self.scaled_data,['normalization'],dim_reduction_methods)
        dim_optimiser.optimize_all()
        end_time = time.time()
        self.n_components = dim_optimiser.n_components_dict
        logging.info(f"Optimization complete. n_components: {self.n_components}")
        logging.info(f"Time taken for n_components of dimension reduction optimization: {end_time - start_time} seconds")

        # Apply dimension reduction once for each combination of scaling and dimension reduction method
        # for scaling in scaling_methods:
        #     for dim_method in dim_reduction_methods:
        #         print('applying dimension reduction')
        #         print(scaling,dim_method)
        #         self.reduced_data[(scaling, dim_method)] = self.apply_dimension_reduction(
        #             dim_method, self.n_components['normalization'][dim_method], scaling
        #         )

        print('Applying dimension reduction in parallel')
        logging.info("Applying dimension reduction in parallel")
        start_time = time.time()
        tasks = [(scale, dim) 
                 for dim in dim_reduction_methods 
                 for scale in scaling_methods]
        
        self.reduced_data = {}
        with ProcessPoolExecutor() as executor:
            futures = {executor.submit(self.apply_dimension_reduction, task): task for task in tasks}
            for future in as_completed(futures):
                task = futures[future]
                result = future.result()
                self.reduced_data[task] = result
                # selector.reduced_data[method[0]][method[1]] = result
                print(f"applying dimension reduction complete for {task[1]} with {task[0]} scaling")
                logging.info(f"applying dimension reduction complete for {task[1]} with {task[0]} scaling")
        end_time = time.time()
        logging.info(f"Time taken for applying using best N_components of dimension reduction: {end_time - start_time} seconds")

        logging.info("Starting to process of selecting best model in parallel")
        start_time = time.time()
        tasks = [( model_name, model,scaling, dim) 
                 for model_name, model in models.items()
                 for scaling in scaling_methods 
                 for dim in dim_reduction_methods 
                 ]
        self.results = []
        with ProcessPoolExecutor() as executor:
            futures = [executor.submit(self.process_model, task) for task in tasks]
            for future in as_completed(futures):
                temp_result = future.result()
                if temp_result is not None:
                    self.results.append(temp_result)
                    print(f"processing model complete for {temp_result['model']} with {temp_result['scaling_method']} scaling and {temp_result['dim_reduction_method']} dimension reduction")
                    logging.info(f"processing model complete for {temp_result['model']} with {temp_result['scaling_method']} scaling and {temp_result['dim_reduction_method']} dimension reduction")
       

        # Sort results by silhouette score (descending) and Davies-Bouldin score (ascending)
        sorted_results = sorted(self.results, key=lambda x: (x['silhouette_score'], -x['davies_bouldin_score']), reverse=True)
        best_model = sorted_results[0]

        end_time = time.time()
        logging.info(f"Time taken for processing all models and finding best model: {end_time - start_time} seconds")

        # Store sorted results as DataFrame
        results_df = pd.DataFrame(sorted_results)

        # Return the scaling method and dimension reduction method used in the best model
        best_scaling = best_model['scaling_method']
        best_dim_reduction = best_model['dim_reduction_method']
        best_n_components = best_model['n_components']
        best_n_clusters = best_model['n_clusters']

        logging.info("Finished select_best_model")
        return best_model, best_scaling, best_dim_reduction, best_n_components, best_n_clusters, results_df

def load_data(file_path):
    """
    Load data from a CSV file.

    Parameters
    ----------
    file_path : str
        The path to the CSV file.

    Returns
    -------
    pandas.DataFrame
        The loaded data.
    """
    logging.info(f"Loading data from {file_path}")
    data = pd.read_csv(file_path)
    logging.info("Data loaded successfully")
    return data


# Hyperparameter Tuning Class
class HyperparameterTuner:
    """
    A class for tuning hyperparameters of clustering models.

    Parameters
    ----------
    best_model : str
        The name of the best clustering model.
    scaled_data : numpy.ndarray
        The scaled data used for clustering.
    reduced_data : numpy.ndarray
        The dimension-reduced data.
    n_clusters : int
        The number of clusters.
    random_seed : int, optional
        Random seed for reproducibility (default is 42).

    Attributes
    ----------
    best_model : str
        The name of the best clustering model.
    scaled_data : numpy.ndarray
        The scaled data used for clustering.
    reduced_data : numpy.ndarray
        The dimension-reduced data.
    n_clusters : int
        The number of clusters.
    random_seed : int
        Random seed for reproducibility.
    final_model : object
        The final tuned model.
    best_params : dict
        The best hyperparameters found during tuning.
    """

    def __init__(self, best_model, scaled_data, reduced_data, n_clusters, random_seed=42):
        self.best_model = best_model
        self.scaled_data = scaled_data
        self.reduced_data = reduced_data
        self.n_clusters = n_clusters
        self.random_seed = random_seed
        self.final_model = None
        self.best_params = None
        logging.info("HyperparameterTuner initialized")

    def custom_silhouette_scorer(self, estimator):
        """
        Custom scorer function for silhouette score.

        Parameters
        ----------
        estimator : object
            The clustering model.

        Returns
        -------
        float
            The silhouette score.
        """
        # logging.info("Calculating custom silhouette score")
        labels = estimator.fit_predict(self.reduced_data)
        if len(set(labels)) > 1:  # Ensure we have more than one cluster
            score = silhouette_score(self.scaled_data, labels)
        else:
            score = -1  # Penalize single cluster solutions
        # logging.info(f"Custom silhouette score: {score}")
        return score

    def tune_hyperparameters(self):
        """
        Tune hyperparameters for the best clustering model.

        Returns
        -------
        tuple
            A tuple containing the final tuned model and the best hyperparameters.
        """
        logging.info("Starting hyperparameter tuning")
        start_time = time.time()
        clustering_method = self.best_model

        # Create the custom scorer
        custom_scorer = make_scorer(self.custom_silhouette_scorer, greater_is_better=True)

        # Unified tuning function
        self.final_model, self.best_params = self.tune_model(clustering_method, self.n_clusters, custom_scorer)
        end_time = time.time()
        logging.info(f"Time taken for hyperparameter tuning: {end_time - start_time} seconds")
        logging.info("Finished hyperparameter tuning")
        return self.final_model, self.best_params

    def tune_model(self, clustering_method, n_clusters, custom_scorer):
        """
        Tune hyperparameters for a specific clustering model.

        Parameters
        ----------
        data : numpy.ndarray
            The input data for clustering.
        clustering_method : str
            The name of the clustering method.
        n_clusters : int
            The number of clusters.
        custom_scorer : callable
            The custom scoring function.

        Returns
        -------
        tuple
            A tuple containing the best model and its parameters.
        """
        logging.info(f"Tuning model for {clustering_method}")
        if clustering_method == 'KMeans':
            model = KMeans(random_state=self.random_seed)
            param_grid = {
                'n_clusters': [n_clusters],
                'init': ['k-means++', 'random'],
                'n_init': [10, 20, 30],
                'max_iter': [200, 300, 500]
            }
        elif clustering_method == 'Agglomerative':
            model = AgglomerativeClustering()
            param_grid = {
                'n_clusters': [n_clusters],
                'linkage': ['ward', 'complete', 'average'],
            }
            if 'ward' in param_grid['linkage']:
                param_grid['metric'] = ['euclidean']
            else:
                param_grid['metric'] = ['euclidean', 'manhattan', 'cosine']
        elif clustering_method == 'DBSCAN':
            # Determine optimal eps using k-distance graph
            neighbors = NearestNeighbors(n_neighbors=2)
            nbrs = neighbors.fit(self.reduced_data)
            distances, _ = nbrs.kneighbors(self.reduced_data)
            distances = np.sort(distances, axis=0)
            distances = distances[:,1]
            
            knee = KneeLocator(range(len(distances)), distances, curve='convex', direction='increasing')
            optimal_eps = distances[knee.knee]

            model = DBSCAN()
            param_grid = {
                'eps': [optimal_eps, optimal_eps*0.8, optimal_eps*1.2],
                'min_samples': range(2, 11)
            }
        elif clustering_method == 'HDBSCAN':
            model = hdbscan.HDBSCAN()
            param_grid = {
                'min_cluster_size': range(5, 51, 5),
                'min_samples': range(1, 11),
                'cluster_selection_epsilon': [0, 0.1, 0.5, 1.0],
                'alpha': [0.5, 1.0, 1.5]
            }
        else:
            raise ValueError(f"Unsupported clustering method: {clustering_method}")

        if clustering_method in ['KMeans', 'Agglomerative', 'DBSCAN']:
            grid_search = GridSearchCV(model, param_grid, cv=5, scoring=custom_scorer, n_jobs=-1)
            grid_search.fit(self.reduced_data)
            logging.info(f"Best parameters for {clustering_method}: {grid_search.best_params_}")
            return grid_search.best_estimator_, grid_search.best_params_
        elif clustering_method == 'HDBSCAN':
            best_score = -np.inf
            best_params = None
            best_model = None

            for params in ParameterGrid(param_grid):
                hdbscan_model = hdbscan.HDBSCAN(**params)
                labels = hdbscan_model.fit_predict(self.reduced_data)
                if len(np.unique(labels)) < 4:
                    continue
                score = self.custom_silhouette_scorer(hdbscan_model)
                if score > best_score:
                    best_score = score
                    best_params = params
                    best_model = hdbscan_model

            if best_model is None:
                logging.info("No valid HDBSCAN model found with at least 4 clusters")
                return None, None

            logging.info(f"Best parameters for HDBSCAN: {best_params}")
            return best_model, best_params

    def generate_final_model_and_predict(self, original_data):
        """
        Generate the final model and make predictions on the original data.

        Parameters
        ----------
        original_data : pandas.DataFrame
            The original input data.

        Returns
        -------
        pandas.DataFrame
            The original data with cluster predictions added.
        """
        logging.info("Generating final model and predictions")
        print(original_data.columns)
        if self.final_model is None or self.best_params is None:
            raise ValueError("Please run tune_hyperparameters() first.")

        # Generate predictions
        predictions = self.final_model.fit_predict(self.reduced_data)

        # Add predictions to original data
        result_data = original_data.copy()
        result_data['Cluster'] = predictions

        
        return result_data

def run_clustering_pipeline(data_path):
    """
    Run the complete clustering pipeline.

    Parameters
    ----------
    data_path : str
        The path to the input data file.

    Returns
    -------
    pandas.DataFrame
        The original data with cluster assignments.
    """
    logging.info("Starting clustering pipeline")
    start_time = time.time()
    
    # Load the data
    data = load_data(data_path)
    
    # Create ModelSelector object and select the best model
    selector = ModelSelector(data.copy())
    best_model, best_scaling, best_dim_reduction, best_n_components, best_n_clusters, results_df = selector.select_best_model(use_vif=False)
    
    logging.info(f"Best Model: {best_model}")
    logging.info(f"Best Scaling Method: {best_scaling}")
    logging.info(f"Best Dimension Reduction Method: {best_dim_reduction}")
    logging.info(f"Best Number of Components: {best_n_components}")
    logging.info(f"Best Number of Clusters: {best_n_clusters}")
    logging.info("\nAll Results:")
    logging.info(results_df.to_string())

    # Prepare scaled and reduced data
    scaled_data = selector.scaled_data[best_scaling]
    reduced_data = selector.reduced_data[(best_scaling, best_dim_reduction)]

    # Use the HyperparameterTuner
    logging.info("Starting hyperparameter tuning")

    tuner = HyperparameterTuner(best_model['model'], scaled_data, reduced_data, best_n_clusters)
    final_model, best_params = tuner.tune_hyperparameters()

    logging.info(f"\nBest Hyperparameters: {best_params}")
    logging.info(f"Final Model: {final_model}")

    # Generate final model, predict, and save results
    results_with_clusters = tuner.generate_final_model_and_predict(data)


    cluster_mapping = {k:'cluster_'+str(k) for k in results_with_clusters.Cluster.unique()}
    results_with_clusters['Cluster'] = results_with_clusters['Cluster'].map(cluster_mapping)
    # Save results as CSV
        # Create model_output folder if it doesn't exist
    os.makedirs('model_output', exist_ok=True)
    
    # Save results as CSV in model_output folder
    output_path = os.path.join('model_output', 'clustering_results.csv')
    results_with_clusters.to_csv(output_path, index=False)
    

    logging.info(f"Clustering results have been saved to '{output_path}'")
    # result_data.to_csv('clustering_results.csv', index=False)
    logging.info("\nClustering completed. Results added to original data and saved as CSV.")
    
    # Save the final model
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    model_filename = f'models/final_model_{timestamp}.joblib'
    joblib.dump(final_model, model_filename)
    logging.info(f"Final model saved as {model_filename}")
    
    # Save model metadata
    model_metadata = {
        'model_name': best_model['model'],
        'scaling_method': best_scaling,
        'dim_reduction_method': best_dim_reduction,
        'n_clusters': best_n_clusters,
        'n_components': best_n_components,
        'best_params': best_params
    }
    metadata_filename = f'models/model_metadata_{timestamp}.csv'
    pd.DataFrame([model_metadata]).to_csv(metadata_filename, index=False)
    logging.info(f"Model metadata saved as {metadata_filename}")
    
    end_time = time.time()
    total_time = end_time - start_time
    logging.info(f"Total time taken: {total_time:.2f} seconds")


def autocluster(data_path):
    print("Starting clustering pipeline")
    # Set up logging
    log_folder = os.path.join('logger', 'autocluster_logger')
    os.makedirs(log_folder, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_filename = os.path.join(log_folder, f'clustering_log_{timestamp}.log')
    logging.basicConfig(filename=log_filename, level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

    # Create models folder if it doesn't exist
    os.makedirs('models', exist_ok=True)

    results = run_clustering_pipeline(data_path)
    logging.info("Clustering pipeline completed successfully.")


if __name__ == "__main__":
    autocluster('../../data.csv')# def autocluster(data_path):
    print("Starting clustering pipeline")

    # Create models folder if it doesn't exist


# if __name__ == "__main__":
#     autocluster('../../data.csv')

# import pandas as pd
# import numpy as np
# from sklearn.preprocessing import StandardScaler, MinMaxScaler, OrdinalEncoder, OneHotEncoder
# from sklearn.decomposition import PCA
# from sklearn.manifold import TSNE
# from umap import UMAP
# from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
# from sklearn.metrics import silhouette_score, davies_bouldin_score, make_scorer
# from sklearn.impute import KNNImputer
# from sklearn.compose import ColumnTransformer
# from sklearn.pipeline import Pipeline
# from sklearn.model_selection import ParameterGrid, GridSearchCV
# from sklearn.neighbors import NearestNeighbors
# import hdbscan
# import multiprocessing
# from functools import partial
# from concurrent.futures import ProcessPoolExecutor, as_completed
# from statsmodels.stats.outliers_influence import variance_inflation_factor
# from kneed import KneeLocator
# import time
# import logging
# import os
# from datetime import datetime
# import joblib


# class ModelSelector:
#     """
#     A class for selecting the best clustering model based on various preprocessing and dimension reduction techniques.

#     Parameters
#     ----------
#     data : pandas.DataFrame
#         The input data to be clustered.

#     Attributes
#     ----------
#     data : pandas.DataFrame
#         The input data.
#     transformed_data : pandas.DataFrame
#         The preprocessed data.
#     scaled_data : dict
#         Dictionary containing scaled versions of the data.
#     reduced_data : dict
#         Dictionary containing dimension-reduced versions of the data.
#     results : list
#         List to store results of different clustering models.
#     preprocessor : object
#         The preprocessing pipeline.
#     random_seed : int
#         Random seed for reproducibility.
#     """

#     def __init__(self, data):
#         self.data = data
#         self.transformed_data = None
#         self.scaled_data = {}
#         self.reduced_data = {}
#         self.results = []
#         self.preprocessor = None
#         self.random_seed = 42
#         logging.info("ModelSelector initialized")

#     def prepare_data_for_preprocessing(self):
#         """
#         Prepare the data for preprocessing by removing features with high missing values
#         and identifying numeric and categorical columns.

#         Returns
#         -------
#         None
#         """

#         # Checking for the primary key 
#         unique_col = [col for col in self.data.columns if self.data[col].nunique() == len(self.data)]
#         self.data.set_index(unique_col, inplace=True)


        
#         logging.info("Starting prepare_data_for_preprocessing")
#         # Remove features with 80% or more missing values
#         missing_threshold = len(self.data) * 0.8
#         filtered_data = self.data.dropna(axis=1, thresh=missing_threshold)
        
#         # Identify numeric and categorical columns  
#         one_hot_cat_col = []
#         ordinal_cat_col = []
#         numerical_features = self.data.select_dtypes(include=['int64', 'float64']).columns
#         categorical_features = self.data.select_dtypes(include=['object']).columns
#         for feature in categorical_features:
#             unique_values = self.data[feature].nunique()
#             if unique_values < 4:
#                 one_hot_cat_col.append(feature)
#             else:
#                 ordinal_cat_col.append(feature)
#         self.one_hot_cat_col = one_hot_cat_col
#         self.ordinal_cat_col = ordinal_cat_col
#         self.numerical_col = numerical_features
#         logging.info("Finished prepare_data_for_preprocessing")

#     def data_preprocess_pipeline(self):
#         """
#         Create and apply the data preprocessing pipeline.

#         Returns
#         -------
#         None
#         """
#         logging.info("Starting data_preprocess_pipeline")
#         # Build preprocessing pipeline for numerical features
#         logging.info("KNN imputer for missing values")
#         numerical_pipeline = Pipeline(steps=[
#             ('imputer', KNNImputer(n_neighbors=5)),
#         #     ('scaler', MinMaxScaler())
#         ])
#         # Build preprocessing pipeline for categorical features
#         logging.info("One hot encoding for the Categorical features with less than 4 unique values")
        
#         onehot_categorical_pipeline = Pipeline(steps=[
#             ('onehot_encoding', OneHotEncoder(sparse_output=False, handle_unknown='ignore'))])
        
#         logging.info("Ordinal encoding for the Categorical features with greater than 4 unique values")

#         ordinal_categorical_pipeline = Pipeline(steps=[
#             ('ordinal_encoding', OrdinalEncoder())

#         ])
#         column_transform = ColumnTransformer([
#             ('numerical_columns', numerical_pipeline, self.numerical_col),
#             ('onehot_categorical_columns', onehot_categorical_pipeline, self.one_hot_cat_col),
#             ('ordinal_categorical_columns', ordinal_categorical_pipeline, self.ordinal_cat_col)   
#         ])
#         self.transformed_data = pd.DataFrame(column_transform.fit_transform(self.data)) 
#         one_hot_cols = list(onehot_categorical_pipeline.fit(self.data[self.one_hot_cat_col]).get_feature_names_out())   
#         trans_cols = list(self.numerical_col)+one_hot_cols+list(self.ordinal_cat_col)  
#         self.transformed_data.columns = trans_cols 
#         self.transformed_data.to_csv('transformed_data.csv', index=False)
#         logging.info("Finished data_preprocess_pipeline")

#     def remove_multicollinearity(self, correlation_threshold=0.85, use_vif=False, vif_threshold=5):
#         """
#         Remove multicollinearity from the transformed data.

#         Parameters
#         ----------
#         correlation_threshold : float, optional
#             The threshold for correlation above which features are considered collinear (default is 0.85).
#         use_vif : bool, optional
#             Whether to use Variance Inflation Factor (VIF) for multicollinearity detection (default is False).
#         vif_threshold : float, optional
#             The threshold for VIF above which features are considered to have high multicollinearity (default is 5).

#         Returns
#         -------
#         None
#         """
#         logging.info("Starting remove_multicollinearity")
#         # Remove highly correlated features
#         corr_matrix = self.transformed_data.corr().abs()
#         upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
#         to_drop = [column for column in upper.columns if any(upper[column] > correlation_threshold)]
#         self.transformed_data = self.transformed_data.drop(to_drop, axis=1)

#         if use_vif:
#             # Calculate VIF and remove features with high VIF
#             X = self.transformed_data.values
#             vif = pd.DataFrame()
#             vif["features"] = self.transformed_data.columns
#             vif["VIF"] = [variance_inflation_factor(X, i) for i in range(X.shape[1])]
            
#             while vif["VIF"].max() > vif_threshold:
#                 feature_to_drop = vif.loc[vif["VIF"].idxmax(), "features"]
#                 self.transformed_data = self.transformed_data.drop(feature_to_drop, axis=1)
                
#                 X = self.transformed_data.values
#                 vif = pd.DataFrame()
#                 vif["features"] = self.transformed_data.columns
#                 vif["VIF"] = [variance_inflation_factor(X, i) for i in range(X.shape[1])]
#         logging.info("Finished remove_multicollinearity")

#     def scale_data(self):
#         """
#         Scale the transformed data using normalization and standardization.

#         Returns
#         -------
#         None
#         """
#         logging.info("Starting scale_data")
#         self.scaled_data['normalization'] = MinMaxScaler().fit_transform(self.transformed_data)
#         self.scaled_data['standardization'] = StandardScaler().fit_transform(self.transformed_data)
#         logging.info("Finished scale_data")

#     def find_best_n_components(self, method, threshold=0.95):
#         """
#         Find the best number of components for dimension reduction methods.

#         Parameters
#         ----------
#         method : str
#             The dimension reduction method ('PCA', 'TSNE', or 'UMAP').
#         threshold : float, optional
#             The variance threshold for PCA (default is 0.95).

#         Returns
#         -------
#         int
#             The best number of components.
#         """
#         logging.info(f"Starting find_best_n_components for {method}")
#         if method == 'PCA':
#             pca = PCA(random_state=self.random_seed)
#             pca.fit(self.scaled_data['standardization'])  # Use standardized data for PCA
#             cumulative_variance = np.cumsum(pca.explained_variance_ratio_)
#             n_components = np.argmax(cumulative_variance >= threshold) + 1
#             result = max(4, min(n_components, 10))  # Ensure it's between 4 and 10
#         elif method in ['UMAP', 'TSNE']:
#             n_components_range = range(4, 11) if method == 'UMAP' else [2, 3]
#             with ProcessPoolExecutor() as executor:
#                 evaluate_func = partial(self.evaluate_n_components, method=method)
#                 results = list(executor.map(evaluate_func, n_components_range))
#             result, _ = max(zip(n_components_range, results), key=lambda x: x[1])
#         else:
#             raise ValueError("Unsupported dimension reduction method")
#         logging.info(f"Finished find_best_n_components for {method}. Best n_components: {result}")
#         return result

#     def evaluate_n_components(self, n, method):
#         """
#         Evaluate the performance of a given number of components for a dimension reduction method.

#         Parameters
#         ----------
#         n : int
#             The number of components to evaluate.
#         method : str
#             The dimension reduction method.

#         Returns
#         -------
#         float
#             The silhouette score for the given number of components.
#         """
#         logging.info(f"Evaluating {n} components for {method}")
#         reduced_data = self.apply_dimension_reduction(method, n, 'standardization')
#         kmeans = KMeans(n_clusters=3, random_state=self.random_seed)
#         labels = kmeans.fit_predict(reduced_data)
#         score = silhouette_score(self.scaled_data['standardization'], labels)
#         logging.info(f"Silhouette score for {n} components: {score}")
#         return score

#     def apply_dimension_reduction(self, method, n_components, scaling_method):
#         """
#         Apply dimension reduction to the scaled data.

#         Parameters
#         ----------
#         method : str
#             The dimension reduction method ('PCA', 'TSNE', or 'UMAP').
#         n_components : int
#             The number of components to use.
#         scaling_method : str
#             The scaling method used ('normalization' or 'standardization').

#         Returns
#         -------
#         numpy.ndarray
#             The reduced data.
#         """
#         logging.info(f"Applying {method} with {n_components} components")
#         if method == 'PCA':
#             reducer = PCA(n_components=n_components)
#         elif method == 'TSNE':
#             reducer = TSNE(n_components=n_components)
#         elif method == 'UMAP':
#             reducer = UMAP(n_components=n_components)
#         result = reducer.fit_transform(self.scaled_data[scaling_method])
#         logging.info(f"Finished applying {method}")
#         return result

#     def evaluate_model(self, data, labels):
#         """
#         Evaluate the clustering model using silhouette score and Davies-Bouldin score.

#         Parameters
#         ----------
#         data : numpy.ndarray
#             The data used for clustering.
#         labels : numpy.ndarray
#             The cluster labels.

#         Returns
#         -------
#         tuple
#             A tuple containing the silhouette score and Davies-Bouldin score.
#         """
#         logging.info("Evaluating model")
#         sil_score = silhouette_score(data, labels)
#         db_score = davies_bouldin_score(data, labels)
#         logging.info(f"Silhouette score: {sil_score}, Davies-Bouldin score: {db_score}")
#         return sil_score, db_score

#     def process_model(self, args):
#         """
#         Process a single clustering model with given parameters.

#         Parameters
#         ----------
#         args : tuple
#             A tuple containing scaling method, dimension reduction method, model name, and model object.

#         Returns
#         -------
#         dict or None
#             A dictionary containing the results of the model evaluation, or None if the model is not created.
#         """
#         scaling_method, dim_method, model_name, model = args
#         logging.info(f"Processing model: {model_name} with {scaling_method} scaling and {dim_method} dimension reduction")
#         reduced_data = self.reduced_data[(scaling_method, dim_method)]
#         scaled_data = self.scaled_data[scaling_method]

#         n_clusters = None  # Default for DBSCAN and HDBSCAN
#         if model_name == 'KMeans' or model_name == 'Agglomerative':
#             n_clusters = self.select_best_n_clusters(reduced_data, model_name)
#             if n_clusters is not None:
#                     model.set_params(n_clusters=n_clusters)
#                     labels = model.fit_predict(reduced_data)
#             else:
#                 logging.info(f"Model not created because n_clusters is None for {model_name}")
#                 return None 

#         if model_name == 'HDBSCAN':
#             labels = model.fit_predict(reduced_data)
#         else:
#             labels = model.fit_predict(reduced_data)

#         if len(np.unique(labels)) < 4:
#             logging.info(f"Model not created because less than 4 clusters were found for {model_name}")
#             return None
#         sil_score, db_score = self.evaluate_model(scaled_data, labels)
#         result = {
#             'model': model_name,
#             'scaling_method': scaling_method,
#             'dim_reduction_method': dim_method,
#             'n_components': self.n_components[dim_method],
#             'n_clusters': n_clusters,
#             'silhouette_score': sil_score,
#             'davies_bouldin_score': db_score
#         }
#         logging.info(f"Finished processing model: {model_name}")
#         return result

#     def select_best_n_clusters(self, data, model_type):
#         """
#         Select the best number of clusters for KMeans and Agglomerative clustering.

#         Parameters
#         ----------
#         data : numpy.ndarray
#             The data used for clustering.
#         model_type : str
#             The type of clustering model ('KMeans' or 'Agglomerative').

#         Returns
#         -------
#         int
#             The best number of clusters.
#         """
#         logging.info(f"Selecting best n_clusters for {model_type}")
#         cluster_range = range(4, 11)

#         if model_type == 'KMeans':
#             # KMeans - Elbow Method
#             inertias = []
#             for n in cluster_range:
#                 kmeans = KMeans(n_clusters=n, random_state=self.random_seed)
#                 kmeans.fit(data)
#                 inertias.append(kmeans.inertia_)

#             kl = KneeLocator(cluster_range, inertias, curve='convex', direction='decreasing')
#             result = kl.elbow
#         elif model_type == 'Agglomerative':
#             # Agglomerative - Using evaluate_model function
#             scores = []
#             for n in cluster_range:
#                 agglomerative = AgglomerativeClustering(n_clusters=n)
#                 labels = agglomerative.fit_predict(data)
#                 sil_score, _ = self.evaluate_model(data, labels)
#                 scores.append(sil_score)

#             result = cluster_range[np.argmax(scores)]
#         logging.info(f"Best n_clusters for {model_type}: {result}")
#         return result

#     def select_best_model(self, correlation_threshold=0.85, use_vif=False, vif_threshold=5):
#         """
#         Select the best clustering model based on various preprocessing and dimension reduction techniques.

#         Parameters
#         ----------
#         correlation_threshold : float, optional
#             The threshold for correlation in multicollinearity removal (default is 0.85).
#         use_vif : bool, optional
#             Whether to use Variance Inflation Factor for multicollinearity removal (default is False).
#         vif_threshold : float, optional
#             The threshold for VIF in multicollinearity removal (default is 5).

#         Returns
#         -------
#         tuple
#             A tuple containing the best model, scaling method, dimension reduction method, number of components,
#             number of clusters, and a DataFrame of all results.
#         """
#         logging.info("Starting select_best_model")
#         self.prepare_data_for_preprocessing()
#         self.data_preprocess_pipeline()
#         self.remove_multicollinearity(correlation_threshold, use_vif, vif_threshold)
#         self.scale_data()
#         scaling_methods = ['normalization', 'standardization']
#         dim_reduction_methods = ['PCA', 'TSNE', 'UMAP']

#         models = {
#             'KMeans': KMeans(random_state=self.random_seed),  # n_clusters will be set in process_model
#             'DBSCAN': DBSCAN(eps=0.5, min_samples=5),
#             'Agglomerative': AgglomerativeClustering(),  # n_clusters will be set in process_model
#             'HDBSCAN': hdbscan.HDBSCAN(min_cluster_size=5)
#         }

#         # Find best n_components for each dimension reduction method
#         self.n_components = {method: self.find_best_n_components(method) for method in dim_reduction_methods}

#         # Apply dimension reduction once for each combination of scaling and dimension reduction method
#         for scaling in scaling_methods:
#             for dim_method in dim_reduction_methods:
#                 self.reduced_data[(scaling, dim_method)] = self.apply_dimension_reduction(
#                     dim_method, self.n_components[dim_method], scaling
#                 )

#         tasks = [(scaling, dim, model_name, model) 
#                  for scaling in scaling_methods 
#                  for dim in dim_reduction_methods 
#                  for model_name, model in models.items()]

#         with ProcessPoolExecutor() as executor:
#             futures = [executor.submit(self.process_model, task) for task in tasks]
#             for future in as_completed(futures):
#                 temp_result = future.result()
#                 if temp_result is not None:
#                     self.results.append(temp_result)

#         # Sort results by silhouette score (descending) and Davies-Bouldin score (ascending)
#         sorted_results = sorted(self.results, key=lambda x: (x['silhouette_score'], -x['davies_bouldin_score']), reverse=True)
#         best_model = sorted_results[0]

#         # Store sorted results as DataFrame
#         results_df = pd.DataFrame(sorted_results)

#         # Return the scaling method and dimension reduction method used in the best model
#         best_scaling = best_model['scaling_method']
#         best_dim_reduction = best_model['dim_reduction_method']
#         best_n_components = best_model['n_components']
#         best_n_clusters = best_model['n_clusters']

#         logging.info("Finished select_best_model")
#         return best_model, best_scaling, best_dim_reduction, best_n_components, best_n_clusters, results_df

# def load_data(file_path):
#     """
#     Load data from a CSV file.

#     Parameters
#     ----------
#     file_path : str
#         The path to the CSV file.

#     Returns
#     -------
#     pandas.DataFrame
#         The loaded data.
#     """
#     logging.info(f"Loading data from {file_path}")
#     data = pd.read_csv(file_path)
#     logging.info("Data loaded successfully")
#     return data


# # Hyperparameter Tuning Class
# class HyperparameterTuner:
#     """
#     A class for tuning hyperparameters of clustering models.

#     Parameters
#     ----------
#     best_model : str
#         The name of the best clustering model.
#     scaled_data : numpy.ndarray
#         The scaled data used for clustering.
#     reduced_data : numpy.ndarray
#         The dimension-reduced data.
#     n_clusters : int
#         The number of clusters.
#     random_seed : int, optional
#         Random seed for reproducibility (default is 42).

#     Attributes
#     ----------
#     best_model : str
#         The name of the best clustering model.
#     scaled_data : numpy.ndarray
#         The scaled data used for clustering.
#     reduced_data : numpy.ndarray
#         The dimension-reduced data.
#     n_clusters : int
#         The number of clusters.
#     random_seed : int
#         Random seed for reproducibility.
#     final_model : object
#         The final tuned model.
#     best_params : dict
#         The best hyperparameters found during tuning.
#     """

#     def __init__(self, best_model, scaled_data, reduced_data, n_clusters, random_seed=42):
#         self.best_model = best_model
#         self.scaled_data = scaled_data
#         self.reduced_data = reduced_data
#         self.n_clusters = n_clusters
#         self.random_seed = random_seed
#         self.final_model = None
#         self.best_params = None
#         logging.info("HyperparameterTuner initialized")

#     def custom_silhouette_scorer(self, estimator, X):
#         """
#         Custom scorer function for silhouette score.

#         Parameters
#         ----------
#         estimator : object
#             The clustering model.
#         X : numpy.ndarray
#             The input data.

#         Returns
#         -------
#         float
#             The silhouette score.
#         """
#         # logging.info("Calculating custom silhouette score")
#         labels = estimator.fit_predict(self.scaled_data)
#         if len(set(labels)) > 1:  # Ensure we have more than one cluster
#             score = silhouette_score(self.scaled_data, labels)
#         else:
#             score = -1  # Penalize single cluster solutions
#         # logging.info(f"Custom silhouette score: {score}")
#         return score

#     def tune_hyperparameters(self):
#         """
#         Tune hyperparameters for the best clustering model.

#         Returns
#         -------
#         tuple
#             A tuple containing the final tuned model and the best hyperparameters.
#         """
#         logging.info("Starting hyperparameter tuning")
#         clustering_method = self.best_model

#         # Create the custom scorer
#         custom_scorer = make_scorer(self.custom_silhouette_scorer, greater_is_better=True)

#         # Unified tuning function
#         self.final_model, self.best_params = self.tune_model(self.scaled_data, clustering_method, self.n_clusters, custom_scorer)
#         logging.info("Finished hyperparameter tuning")
#         return self.final_model, self.best_params

#     def tune_model(self, data, clustering_method, n_clusters, custom_scorer):
#         """
#         Tune hyperparameters for a specific clustering model.

#         Parameters
#         ----------
#         data : numpy.ndarray
#             The input data for clustering.
#         clustering_method : str
#             The name of the clustering method.
#         n_clusters : int
#             The number of clusters.
#         custom_scorer : callable
#             The custom scoring function.

#         Returns
#         -------
#         tuple
#             A tuple containing the best model and its parameters.
#         """
#         logging.info(f"Tuning model for {clustering_method}")
#         if clustering_method == 'KMeans':
#             model = KMeans(random_state=self.random_seed)
#             param_grid = {
#                 'n_clusters': [n_clusters],
#                 'init': ['k-means++', 'random'],
#                 'n_init': [10, 20, 30],
#                 'max_iter': [200, 300, 500]
#             }
#         elif clustering_method == 'Agglomerative':
#             model = AgglomerativeClustering()
#             param_grid = {
#                 'n_clusters': [n_clusters],
#                 'linkage': ['ward', 'complete', 'average'],
#             }
#             if 'ward' in param_grid['linkage']:
#                 param_grid['metric'] = ['euclidean']
#             else:
#                 param_grid['metric'] = ['euclidean', 'manhattan', 'cosine']
#         elif clustering_method == 'DBSCAN':
#             # Determine optimal eps using k-distance graph
#             neighbors = NearestNeighbors(n_neighbors=2)
#             nbrs = neighbors.fit(data)
#             distances, _ = nbrs.kneighbors(data)
#             distances = np.sort(distances, axis=0)
#             distances = distances[:,1]
            
#             knee = KneeLocator(range(len(distances)), distances, curve='convex', direction='increasing')
#             optimal_eps = distances[knee.knee]

#             model = DBSCAN()
#             param_grid = {
#                 'eps': [optimal_eps, optimal_eps*0.8, optimal_eps*1.2],
#                 'min_samples': range(2, 11)
#             }
#         elif clustering_method == 'HDBSCAN':
#             model = hdbscan.HDBSCAN()
#             param_grid = {
#                 'min_cluster_size': range(5, 51, 5),
#                 'min_samples': range(1, 11),
#                 'cluster_selection_epsilon': [0, 0.1, 0.5, 1.0],
#                 'alpha': [0.5, 1.0, 1.5]
#             }
#         else:
#             raise ValueError(f"Unsupported clustering method: {clustering_method}")

#         if clustering_method in ['KMeans', 'Agglomerative', 'DBSCAN']:
#             grid_search = GridSearchCV(model, param_grid, cv=5, scoring=custom_scorer, n_jobs=-1)
#             grid_search.fit(data)
#             logging.info(f"Best parameters for {clustering_method}: {grid_search.best_params_}")
#             return grid_search.best_estimator_, grid_search.best_params_
#         elif clustering_method == 'HDBSCAN':
#             best_score = -np.inf
#             best_params = None
#             best_model = None

#             for params in ParameterGrid(param_grid):
#                 hdbscan_model = hdbscan.HDBSCAN(**params)
#                 labels = hdbscan_model.fit_predict(data)
#                 if len(np.unique(labels)) < 4:
#                     continue
#                 score = self.custom_silhouette_scorer(hdbscan_model, data)
#                 if score > best_score:
#                     best_score = score
#                     best_params = params
#                     best_model = hdbscan_model

#             if best_model is None:
#                 logging.info("No valid HDBSCAN model found with at least 4 clusters")
#                 return None, None

#             logging.info(f"Best parameters for HDBSCAN: {best_params}")
#             return best_model, best_params

#     def generate_final_model_and_predict(self, original_data):
#         """
#         Generate the final model and make predictions on the original data.

#         Parameters
#         ----------
#         original_data : pandas.DataFrame
#             The original input data.

#         Returns
#         -------
#         pandas.DataFrame
#             The original data with cluster predictions added.
#         """
#         logging.info("Generating final model and predictions")
#         if self.final_model is None or self.best_params is None:
#             raise ValueError("Please run tune_hyperparameters() first.")

#         # Generate predictions
#         predictions = self.final_model.fit_predict(self.scaled_data)

#         # Add predictions to original data
#         result_data = original_data.copy()
#         result_data['Cluster'] = predictions

        
#         return result_data

# def run_clustering_pipeline(data_path):
#     """
#     Run the complete clustering pipeline.

#     Parameters
#     ----------
#     data_path : str
#         The path to the input data file.

#     Returns
#     -------
#     pandas.DataFrame
#         The original data with cluster assignments.
#     """
#     logging.info("Starting clustering pipeline")
#     start_time = time.time()
    
#     # Load the data
#     data = load_data(data_path)
    
#     # Create ModelSelector object and select the best model
#     selector = ModelSelector(data)
#     best_model, best_scaling, best_dim_reduction, best_n_components, best_n_clusters, results_df = selector.select_best_model(use_vif=False)
    
#     logging.info(f"Best Model: {best_model}")
#     logging.info(f"Best Scaling Method: {best_scaling}")
#     logging.info(f"Best Dimension Reduction Method: {best_dim_reduction}")
#     logging.info(f"Best Number of Components: {best_n_components}")
#     logging.info(f"Best Number of Clusters: {best_n_clusters}")
#     logging.info("\nAll Results:")
#     logging.info(results_df.to_string())

#     # Prepare scaled and reduced data
#     scaled_data = selector.scaled_data[best_scaling]
#     reduced_data = selector.reduced_data[(best_scaling, best_dim_reduction)]

#     # Use the HyperparameterTuner
#     logging.info("Starting hyperparameter tuning")

#     tuner = HyperparameterTuner(best_model['model'], scaled_data, reduced_data, best_n_clusters)
#     final_model, best_params = tuner.tune_hyperparameters()

#     logging.info(f"\nBest Hyperparameters: {best_params}")
#     logging.info(f"Final Model: {final_model}")

#     # Generate final model, predict, and save results
#     results_with_clusters = tuner.generate_final_model_and_predict(data)


#     cluster_mapping = {k:'cluster_'+k for k in results_with_clusters.Cluster.unique()}
#     results_with_clusters['Cluster'] = results_with_clusters['Cluster'].map(cluster_mapping)
#     # Save results as CSV
#         # Create model_output folder if it doesn't exist
#     os.makedirs('model_output', exist_ok=True)
    
#     # Save results as CSV in model_output folder
#     output_path = os.path.join('model_output', 'clustering_results.csv')
#     results_with_clusters.to_csv(output_path, index=False)
    

#     logging.info(f"Clustering results have been saved to '{output_path}'")
#     # result_data.to_csv('clustering_results.csv', index=False)

#     # logging.info("Clustering results have been saved to 'clustering_results.csv'")


#     logging.info("\nClustering completed. Results added to original data and saved as CSV.")

#     # Save the final model
#     timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
#     model_filename = f'models/final_model_{timestamp}.joblib'
#     joblib.dump(final_model, model_filename)
#     logging.info(f"Final model saved as {model_filename}")

#     # Save model metadata
#     model_metadata = {
#         'model_name': best_model['model'],
#         'scaling_method': best_scaling,
#         'dim_reduction_method': best_dim_reduction,
#         'n_clusters': best_n_clusters,
#         'n_components': best_n_components,
#         'best_params': best_params
#     }
#     metadata_filename = f'models/model_metadata_{timestamp}.csv'
#     pd.DataFrame([model_metadata]).to_csv(metadata_filename, index=False)
#     logging.info(f"Model metadata saved as {metadata_filename}")

#     end_time = time.time()
#     total_time = end_time - start_time
#     logging.info(f"Total time taken: {total_time:.2f} seconds")

#     return results_with_clusters


